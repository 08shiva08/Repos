# YAML Rules

Ask user:
- timeout values
- URLs
- feature flags
- credentials placeholders

Auto:
- ordering
- comments

Never guess secrets.
