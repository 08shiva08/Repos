# pom.xml Rules

Auto:
- duplicate dependencies same version
- plugin ordering

Ask:
- dependency version mismatch
- Java version mismatch
- Spring parent version mismatch

Validate with mvn dependency:tree
