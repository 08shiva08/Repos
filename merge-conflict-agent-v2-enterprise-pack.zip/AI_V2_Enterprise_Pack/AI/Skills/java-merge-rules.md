# Java Merge Rules

Auto:
- imports
- formatting
- separate methods
- comments

Ask user:
- same method changed both branches
- retry/timeouts
- DTO/API signature changes
- exception behavior changes

Prefer compile-safe and backward compatible changes.
