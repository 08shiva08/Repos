# CSV Audit Logging

Generate:
1. merge_conflict_before.csv
2. merge_conflict_actions.csv
3. merge_conflict_after.csv

Include timestamps, branches, files, decisions, compile status.
