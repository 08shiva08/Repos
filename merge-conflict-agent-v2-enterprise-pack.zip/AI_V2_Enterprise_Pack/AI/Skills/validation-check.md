# Validation

Maven:
mvn -q -DskipTests compile

Gradle:
gradle compileJava

Optional:
mvn test
