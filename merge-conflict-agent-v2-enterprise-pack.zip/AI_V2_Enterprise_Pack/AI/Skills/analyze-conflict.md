# Analyze Conflict

Use conflict markers to compare current vs incoming branch changes.
Determine:
- formatting
- imports
- config
- dependency
- logic
- tests

Recommend low-risk merge when possible.
