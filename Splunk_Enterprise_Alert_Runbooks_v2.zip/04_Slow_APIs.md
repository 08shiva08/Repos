# Slow APIs

## Business Purpose
See runbook.

## Severity
See runbook.

## SPL Query
```spl
index=project_a layer=controller eventType=request_completed
| stats avg(duration) as avgLatency p95(duration) as p95Latency count as requestCount by operation
| where p95Latency>1000
```

## Schedule
Every 1 minute

## Search Window
Last 5 minutes (15 minutes for latency alerts)

## Trigger
Number of Results > 0 (or threshold exceeded)

## Notification
Email, Slack, PagerDuty

## Related Dashboard
See Executive/API dashboard.
