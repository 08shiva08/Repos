# No Traffic

## Business Purpose
See runbook.

## Severity
See runbook.

## SPL Query
```spl
index=project_a eventType=request_completed earliest=-5m
| stats count
| where count=0
```

## Schedule
Every 1 minute

## Search Window
Last 5 minutes (15 minutes for latency alerts)

## Trigger
Number of Results > 0 (or threshold exceeded)

## Notification
Email, Slack, PagerDuty

## Related Dashboard
See Executive/API dashboard.
