# Slow Services

## Business Purpose
See runbook.

## Severity
See runbook.

## SPL Query
```spl
index=project_a layer=service
| stats avg(duration) as avgDuration by operation
| where avgDuration>800
```

## Schedule
Every 1 minute

## Search Window
Last 5 minutes (15 minutes for latency alerts)

## Trigger
Number of Results > 0 (or threshold exceeded)

## Notification
Email, Slack, PagerDuty

## Related Dashboard
See Executive/API dashboard.
