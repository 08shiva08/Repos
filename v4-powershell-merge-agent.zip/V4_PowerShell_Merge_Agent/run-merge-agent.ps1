param([string]$Mode="Balanced",[int]$MaxRetries=5)
$reportDir="Reports"; New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$ts=Get-Date -Format "yyyyMMdd_HHmmss"
$before="$reportDir\before_$ts.csv"; "timestamp,status"|Set-Content $before
$conflicts = git diff --name-only --diff-filter=U
if(-not $conflicts){ Write-Host "No conflicts detected"; exit 0 }
$attempt=1
while($attempt -le $MaxRetries){
 if(Test-Path "pom.xml"){ mvn -q -DskipTests compile }
 if(Test-Path "package.json"){ npm run build; npm test -- --watch=false }
 if($LASTEXITCODE -eq 0){ break }
 $attempt++
}
Write-Host "Completed"
