# Client Alerts

## Downstream Timeout
```spl
index=project_a layer=client errorCode=TIMEOUT
| stats count by destination
```

## Client Failures
```spl
index=project_a layer=client status=FAIL
| stats count by source destination
```
