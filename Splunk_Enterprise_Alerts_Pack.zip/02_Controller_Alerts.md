# Controller Alerts

## Slow APIs
```spl
index=project_a layer=controller eventType=request_completed
| stats avg(duration) as avgLatency p95(duration) as p95 by operation
| where p95>1000
```

## Controller Failures
```spl
index=project_a layer=controller status=FAIL
| stats count by operation
```
