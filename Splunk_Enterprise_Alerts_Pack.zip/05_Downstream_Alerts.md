# Downstream Alerts

## Downstream Availability
```spl
index=downstream_* eventType=request_completed
| stats count by service
```

## Downstream Latency
```spl
index=downstream_*
| stats p95(duration) as p95 by service
| where p95>1500
```
