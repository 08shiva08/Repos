# Executive Alerts

## Error Rate High
```spl
index=project_a eventType=request_completed
| stats count as total count(eval(status="FAIL")) as failed
| eval errorRate=(failed*100)/total
| where errorRate>5
```

## Traffic Per Minute
```spl
index=project_a eventType=request_completed
| timechart span=1m count
```

## No Traffic
```spl
index=project_a eventType=request_completed earliest=-5m
| stats count
| where count=0
```
