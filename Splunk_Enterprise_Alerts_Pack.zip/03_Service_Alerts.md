# Service Alerts

## Service Failures
```spl
index=project_a layer=service status=FAIL
| stats count by operation
```

## Slow Services
```spl
index=project_a layer=service
| stats avg(duration) as avgDuration by operation
| where avgDuration>800
```
