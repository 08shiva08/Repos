# Frontend Validation

npm install
npm run build
npm test

If failure:
1. Parse error output
2. Identify impacted file
3. Patch merge-caused issue
4. Re-run build
