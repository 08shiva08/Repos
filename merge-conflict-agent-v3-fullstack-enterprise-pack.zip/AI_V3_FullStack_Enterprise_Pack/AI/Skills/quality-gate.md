# Quality Gate

Success requires:
- Backend compile PASS
- Frontend build PASS
- No failing tests
- No unresolved conflict markers
- Git status clean enough to commit
