# React Merge Rules

Auto:
- imports
- formatting
- separate components
- CSS/module changes in different regions

Ask user:
- same hook modified
- same state logic modified
- route conflicts
- API endpoint changes
- props contract changes

Files:
.js .jsx .ts .tsx package.json vite.config.*