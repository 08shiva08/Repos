# Analyze conflicts and classify file risk.
