# Build Recovery Loop

When build/test fails:
1. Read logs
2. Map failure to merge changes
3. Apply minimal patch
4. Retry build/test
5. Repeat up to 5 cycles
6. Escalate only if semantic ambiguity remains
