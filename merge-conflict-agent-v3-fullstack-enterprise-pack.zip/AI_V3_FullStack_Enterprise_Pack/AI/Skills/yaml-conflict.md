# YAML config conflict handling.
