# Optional Jira Update

If user enables:
Create concise summary of resolved conflicts, files changed, validations passed.
Post through MCP/Jira integration.
