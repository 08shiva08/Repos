# pom.xml dependency/version conflict handling.
