# Service Failures
Monitor business logic failures.
