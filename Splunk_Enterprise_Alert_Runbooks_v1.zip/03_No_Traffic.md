# No Traffic
Critical outage detection.
Window:5 min
Trigger: count=0
