Runbook-style documentation for 8 enterprise Splunk alerts.
Import SPL into Splunk alerts manually or via savedsearches.conf.