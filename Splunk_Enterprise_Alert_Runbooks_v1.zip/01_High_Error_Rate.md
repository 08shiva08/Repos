# High Error Rate
Severity: Critical
Schedule: Every 1 min
Window: Last 5 min
Trigger: Results>0
Threshold: Error rate>5%
Notification: Email, Slack, PagerDuty
