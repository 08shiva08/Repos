# Traffic Per Minute
Purpose: Monitor request volume.
Alert on abnormal spike/drop.
