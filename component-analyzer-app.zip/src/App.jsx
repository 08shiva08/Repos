import React from "react";
import SearchScreen from "./SearchScreen";

const componentJson = [
  {
    name: "Dashboard",
    type: "FunctionalComponent",
    props: ["data"],
    state: ["selectedComponent"],
    summary: "Dashboard manages component selection and loads metadata on mount.",
  },
  {
    name: "MainApp",
    type: "ClassComponent",
    props: ["config"],
    state: ["user", "isLoading"],
    summary: "MainApp fetches user data on mount and manages global app state.",
  },
  {
    name: "ComponentGraph",
    type: "FunctionalComponent",
    props: ["data"],
    summary: "Renders interactive component hierarchy graphs.",
  },
];

export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>React Component Search & Analysis</h1>
      <SearchScreen componentJson={componentJson} />
    </div>
  );
}