import React, { useState, useEffect } from "react";

const OPENAI_API_KEY = "YOUR_OPENAI_API_KEY_HERE"; // Replace securely or use env variables

export default function SearchScreen({ componentJson }) {
  const [query, setQuery] = useState("");
  const [filtered, setFiltered] = useState(componentJson);
  const [selectedComp, setSelectedComp] = useState(null);
  const [gptResponse, setGptResponse] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!query) {
      setFiltered(componentJson);
    } else {
      const q = query.toLowerCase();
      setFiltered(
        componentJson.filter(
          (comp) =>
            comp.name.toLowerCase().includes(q) ||
            (comp.summary && comp.summary.toLowerCase().includes(q))
        )
      );
    }
  }, [query, componentJson]);

  async function analyzeComponent(component) {
    setLoading(true);
    setError(null);
    setSelectedComp(component);
    setGptResponse("");

    const prompt = `Analyze this React component JSON and provide a detailed summary:\n\n${JSON.stringify(
      component,
      null,
      2
    )}`;

    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: "You are a helpful assistant analyzing React components.",
            },
            { role: "user", content: prompt },
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      });

      if (!res.ok) {
        throw new Error(`OpenAI API error: ${res.statusText}`);
      }

      const data = await res.json();
      const chatOutput = data.choices?.[0]?.message?.content || "No response";
      setGptResponse(chatOutput);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }

  return (
    <div style={{ maxWidth: 700, margin: "auto" }}>
      <input
        type="search"
        placeholder="Search components..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{
          width: "100%",
          padding: "0.75rem",
          fontSize: "1rem",
          borderRadius: 8,
          border: "1px solid #ccc",
          marginBottom: 20,
          boxSizing: "border-box",
        }}
      />

      {filtered.length === 0 ? (
        <p style={{ fontStyle: "italic", color: "#777" }}>No components found.</p>
      ) : (
        filtered.map((comp) => (
          <div
            key={comp.name}
            style={{
              border: "1px solid #ddd",
              borderRadius: 8,
              padding: "1rem",
              marginBottom: "1rem",
              boxShadow: "0 2px 5px rgba(0,0,0,0.05)",
              cursor: "pointer",
              transition: "background-color 0.2s",
            }}
            onClick={() => analyzeComponent(comp)}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f9f9f9")}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "white")}
          >
            <h3 style={{ margin: "0 0 0.5rem 0" }}>{comp.name}</h3>
            <small
              style={{
                fontSize: "0.85rem",
                color: "#555",
                display: "block",
                marginBottom: "0.5rem",
              }}
            >
              Type: {comp.type}
            </small>
            <p style={{ margin: 0, color: "#333" }}>{comp.summary}</p>
          </div>
        ))
      )}

      {loading && <p>Loading analysis...</p>}

      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      {gptResponse && (
        <div
          style={{
            marginTop: 30,
            padding: 20,
            backgroundColor: "#eef",
            borderRadius: 8,
            whiteSpace: "pre-wrap",
          }}
        >
          <h2>Analysis for {selectedComp.name}</h2>
          <p>{gptResponse}</p>
        </div>
      )}
    </div>
  );
}