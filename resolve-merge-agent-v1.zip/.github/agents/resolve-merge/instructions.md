# Merge Resolution Instructions

1. Detect markers:
<<<<<<<
=======
>>>>>>>

2. Compare HEAD vs incoming branch.
3. Prefer compilable syntax.
4. Preserve business logic.
5. Combine compatible changes.
6. Remove markers.
7. Verify no markers remain.
8. Generate audit CSV summary.
