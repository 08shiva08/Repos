V1.0.0
Release: Initial self-contained merge conflict agent package.
