# Java Rules

## .java
- Keep package valid
- Merge imports without duplicates
- Preserve annotations
- Keep constructors valid
- Avoid duplicate methods

## pom.xml
- Keep valid XML
- Prefer newer compatible versions
- Avoid duplicate dependencies

## YAML / properties
- Keep valid syntax
- Preserve required keys
