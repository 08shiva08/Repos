# Audit Template

CSV Columns:
timestamp,file_path,file_type,conflict_type,decision,risk_level,resolved
