# Changelog

## V1.0.0
- Added resolve-merge agent
- Added Java merge rules
- Added conflict patterns
- Added audit template
- Added utility agents
