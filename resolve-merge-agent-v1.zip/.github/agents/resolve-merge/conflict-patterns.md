# Conflict Patterns

1. Import conflict -> keep both if needed
2. Method enhancement conflict -> combine changes
3. Version conflict -> prefer newer compatible
4. Delete vs modify -> prefer modified unless obsolete
5. Large refactor -> choose safest compilable path
