# Usage

Run in Copilot Chat / Agent mode:

/resolve-merge
/next-conflict
/conflict-summary
/rollback-last-merge
/confidence-score

Recommended after git pull merge conflict.
