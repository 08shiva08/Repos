---
name: resolve-merge
description: Resolve merge conflicts intelligently across repository files and generate audit output.
tools: read, edit, search
model: default
---

# Resolve Merge Agent

Use sibling markdown files as context.

Primary goals:
1. Search repository for merge conflict markers.
2. Resolve conflicts file by file.
3. Apply Java rules for .java, pom.xml, yml/properties.
4. Remove markers.
5. Produce audit summary.
