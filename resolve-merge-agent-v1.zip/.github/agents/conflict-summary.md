---
name: conflict-summary
description: Summarize all current merge conflicts in repository.
tools: read, search
model: default
---

# Conflict Summary Agent

List files with markers, file types, estimated risk, and suggested order.
