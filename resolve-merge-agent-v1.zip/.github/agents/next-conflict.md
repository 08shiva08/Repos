---
name: next-conflict
description: Navigate to next unresolved merge conflict.
tools: read, search
model: default
---

# Next Conflict Agent

Find next file containing conflict markers and summarize it.
