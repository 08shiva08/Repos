---
name: conflict-summary
description: Summarize all unresolved conflicts across repository.
tools: read, search
model: default
---

# Conflict Summary Agent

List conflicted files, types, severity, suggested order, likely hotspots.
