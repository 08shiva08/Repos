---
name: rollback-last-merge
description: Provide safest rollback guidance for last merge attempt.
tools: read
model: default
---

# Rollback Last Merge

Explain rollback options:
- git merge --abort
- git reset
- restore files

Choose based on current state.
