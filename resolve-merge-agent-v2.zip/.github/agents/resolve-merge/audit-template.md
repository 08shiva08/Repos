# Audit Template

CSV Columns:
timestamp,file_path,file_type,conflict_type,head_used,incoming_used,decision,risk,manual_review,resolved
