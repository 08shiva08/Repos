# Usage

Run in GitHub Copilot Chat / Agent mode:

/resolve-merge
/next-conflict
/conflict-summary
/rollback-last-merge
/confidence-score

Recommended Flow:
1. git pull / merge
2. conflicts occur
3. run /conflict-summary
4. run /resolve-merge
5. run /confidence-score
