# Conflict Patterns

1. Import conflict -> keep both if used
2. Method enhancement -> combine logic
3. Hook conflict -> merge side effects safely
4. Component prop conflict -> preserve backward compatibility
5. Dependency version conflict -> prefer newer compatible
6. Delete vs modify -> preserve modified unless obsolete
7. Large refactor -> safest compilable route
