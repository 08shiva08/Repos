# React Rules

## .js .jsx .ts .tsx

1. Preserve component exports.
2. Keep imports deduplicated.
3. Preserve hooks order consistency.
4. Merge useEffect logic carefully.
5. Preserve props contracts.
6. Avoid duplicate state variables.
7. Preserve TypeScript interfaces/types.
8. Keep event handlers from both sides when compatible.
9. Keep JSX valid and balanced.

## package.json
1. Keep valid JSON.
2. Prefer newer compatible dependency versions.
3. Avoid duplicate packages.

## Styling
- Preserve CSS module imports
- Preserve SCSS imports
- Keep Tailwind class strings valid
