# Merge Resolution Instructions V2

1. Search repository for:
<<<<<<<
=======
>>>>>>>

2. Classify file type:
- Java
- XML
- YAML
- JS/TS
- React JSX/TSX
- JSON
- Markdown
- Other text

3. Compare HEAD vs incoming changes.
4. Prefer:
   - valid syntax
   - preserved business logic
   - combined compatible enhancements
   - newer safe dependency versions

5. Cleanup:
- remove markers
- normalize formatting
- remove duplicates

6. Verify:
- no markers remain
- structure appears valid

7. Output audit summary.
