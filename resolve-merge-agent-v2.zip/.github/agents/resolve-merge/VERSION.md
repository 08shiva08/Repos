V2.0.0
Enhanced Java + React + additional context package.
