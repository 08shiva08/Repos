# Java Rules

## .java
- Keep package valid
- Merge imports without duplicates
- Preserve annotations
- Preserve exception handling
- Keep constructors valid
- Avoid duplicate methods
- Prefer constructor injection

## pom.xml
- Keep valid XML
- Prefer newer compatible versions
- Keep plugins aligned
- Avoid duplicate dependencies

## application.yml / properties
- Keep valid syntax
- Preserve required keys
