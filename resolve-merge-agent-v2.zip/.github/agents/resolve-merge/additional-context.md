# Additional Context

Repository may contain:
- Java Spring Boot backend
- React frontend
- Shared APIs
- CI/CD configs
- Docs

Prioritize preserving integration points between frontend and backend.
