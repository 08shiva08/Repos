---
name: resolve-merge
description: V2 intelligent merge resolver for Java, React, config and repo-wide conflicts with audit outputs.
tools: read, edit, search
model: default
---

# Resolve Merge Agent V2

Load all sibling markdown files as operating context.

Goals:
1. Detect unresolved merge markers across repository.
2. Resolve conflicts using language-aware rules.
3. Apply Java rules for backend files.
4. Apply React rules for frontend files.
5. Preserve behavior from both sides when safe.
6. Remove markers.
7. Generate audit summary and confidence score.
