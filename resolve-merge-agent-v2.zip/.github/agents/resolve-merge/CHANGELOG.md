# Changelog

## V2.0.0
- Added React merge rules
- Added repo integration context
- Improved audit schema
- Improved conflict patterns
- Better mixed frontend/backend support
