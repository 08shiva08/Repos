---
name: next-conflict
description: Find next unresolved merge conflict and summarize likely resolution path.
tools: read, search
model: default
---

# Next Conflict Agent

Locate next file with markers and explain file type, risk and suggested merge approach.
