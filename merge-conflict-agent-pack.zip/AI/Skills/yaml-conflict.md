# Skill: YAML Conflict

For application.yml:

Ask user for:
- timeout changes
- URLs
- credentials placeholders
- feature flags

Auto-resolve:
- comments
- ordering only

Never guess secrets.
