# Skill: pom.xml Conflict

For pom.xml:

Auto-resolve:
- plugin order
- duplicate dependencies same version

Ask user:
- dependency versions differ
- Java version differs
- Spring Boot parent differs

Always verify:
mvn dependency:tree
