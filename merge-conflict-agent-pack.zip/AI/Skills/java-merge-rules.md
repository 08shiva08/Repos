# Skill: Java Merge Rules

For Java files:

Auto-resolve:
- imports
- formatting
- separate new methods
- comments

Ask user:
- same method modified both sides
- changed exception behavior
- changed retry/timeouts
- changed DTO fields
- changed public signatures

Prefer:
- null safety
- backward compatibility
- compile-safe code
