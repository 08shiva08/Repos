# Skill: Analyze Conflict

When conflict markers are present:

<<<<<<< HEAD
...
=======
...
>>>>>>> branch

Do:
1. Identify current branch version
2. Identify incoming branch version
3. Compare intent
4. Detect if changes are formatting, imports, logic, config, tests
5. Recommend low-risk resolution
