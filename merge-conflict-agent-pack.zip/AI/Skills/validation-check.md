# Skill: Validation Check

If Maven:
mvn -q -DskipTests compile

If Gradle:
gradle compileJava

Then optionally:
mvn test

Report:
- compile success/failure
- impacted modules
