import React from "react";

const Metrics = () => {
  return (
    <div style={{ padding: "1rem", backgroundColor: "white", borderRadius: "8px", marginBottom: "1rem" }}>
      <h2>Project Metrics</h2>
      <ul>
        <li>Total Components: 15</li>
        <li>Functional Components: 10</li>
        <li>Class Components: 5</li>
      </ul>
    </div>
  );
};

export default Metrics;