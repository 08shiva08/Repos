import React, { useState } from "react";
import ComponentMap from "./ComponentMap";
import Metrics from "./Metrics";

const Dashboard = () => {
  return (
    <div>
      <Metrics />
      <ComponentMap />
    </div>
  );
};

export default Dashboard;