const fs = require("fs");
const path = require("path");
const { Project } = require("ts-morph");
const fg = require("fast-glob");

const analyzeComponents = (baseDir) => {
  const project = new Project({ tsConfigFilePath: path.join(baseDir, "tsconfig.json"), skipAddingFilesFromTsConfig: true });
  const files = fg.sync(["**/*.{ts,tsx,js,jsx}"], { cwd: baseDir, ignore: ["node_modules"] });

  files.forEach((file) => project.addSourceFileAtPath(path.join(baseDir, file)));
  const sourceFiles = project.getSourceFiles();

  const components = [];

  sourceFiles.forEach((file) => {
    file.getFunctions().forEach((fn) => {
      if (fn.isExported()) {
        components.push({
          name: fn.getName(),
          type: "Functional",
          filePath: file.getFilePath(),
        });
      }
    });

    file.getClasses().forEach((cls) => {
      if (cls.isExported()) {
        components.push({
          name: cls.getName(),
          type: "Class",
          filePath: file.getFilePath(),
        });
      }
    });
  });

  return components;
};

module.exports = { analyzeComponents };