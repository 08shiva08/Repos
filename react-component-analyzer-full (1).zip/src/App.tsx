import React from "react";
import Dashboard from "./components/Dashboard";

const App = () => {
  return (
    <div className="app-container">
      <h1 className="title">React Component Analyzer</h1>
      <Dashboard />
    </div>
  );
};

export default App;