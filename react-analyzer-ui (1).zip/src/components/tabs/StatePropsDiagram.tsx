
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['#8884d8', '#82ca9d'];

export default function StatePropsDiagram({ component }) {
  const stateCount = component.state?.length || 0;
  const propsCount = Object.keys(component.props || {}).length;

  const data = [
    { name: 'State', value: stateCount },
    { name: 'Props', value: propsCount }
  ];

  if (stateCount === 0 && propsCount === 0) {
    return <div className="text-muted">No state or props detected in this component.</div>;
  }

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <PieChart>
          <Pie dataKey="value" data={data} cx="50%" cy="50%" outerRadius={100} label>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
