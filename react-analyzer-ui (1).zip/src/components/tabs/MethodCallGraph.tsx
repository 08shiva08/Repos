
import React from 'react';
import { ResponsiveContainer, Sankey, Tooltip } from 'recharts';

export default function MethodCallGraph({ component }) {
  if (!component?.methods?.length) {
    return <div className="text-muted">No methods detected for this component.</div>;
  }

  const nodes = [];
  const links = [];
  const nodeMap = new Map();
  let nodeIndex = 0;

  function getNodeIndex(name) {
    if (!nodeMap.has(name)) {
      nodeMap.set(name, nodeIndex);
      nodes.push({ name });
      nodeIndex++;
    }
    return nodeMap.get(name);
  }

  component.methods.forEach(method => {
    const sourceIndex = getNodeIndex(method.name);
    method.calls?.forEach(call => {
      const targetIndex = getNodeIndex(call);
      links.push({ source: sourceIndex, target: targetIndex, value: 1 });
    });
  });

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <Sankey width={700} height={400} data={{ nodes, links }} nodePadding={20} margin={{ top: 0, bottom: 0 }}>
          <Tooltip />
        </Sankey>
      </ResponsiveContainer>
    </div>
  );
}
