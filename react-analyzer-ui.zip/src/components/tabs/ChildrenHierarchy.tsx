
import React from 'react';
import { Tree, TreeNode } from 'react-organizational-chart';

export default function ChildrenHierarchy({ component }) {
  if (!component?.children?.length) {
    return <div className="text-muted">No child components found.</div>;
  }

  return (
    <Tree label={<div className="font-bold">{component.id}</div>}>
      {component.children.map((child, index) => (
        <TreeNode key={index} label={<div>{child}</div>} />
      ))}
    </Tree>
  );
}
